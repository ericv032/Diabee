class HomesController < ApplicationController
  def show
  end
end
