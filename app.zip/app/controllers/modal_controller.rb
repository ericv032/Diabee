class ModalController < ApplicationController
end
